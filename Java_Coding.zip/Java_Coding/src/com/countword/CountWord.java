package com.countword;

import java.util.LinkedHashMap;
import java.util.Map;

public class CountWord {

	public static void main(String[] args) {
		
		String para="this is a sentence and this is a character";
		String[] splitWord=para.split(" ");
		
		LinkedHashMap<String,Integer> output= new LinkedHashMap<>();
		
		for(String result:splitWord) {
			
			if(output.containsKey(result)) {
				output.put(result,output.get(result)+1);
			}
			else {
				output.put(result,1);
			}
		}
		System.out.println(output);
	}

}
