package com.findunique;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FindIdentityNum {

	public static void main(String[] args) {
		
		List<Integer> numberList=Arrays.asList(1,2,2,3,4,5,6,7,6,3);
		
		//fetch Identity number from list
		Map<Integer,Long> identityNum=numberList.stream()
				.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		
		List<Integer> output=identityNum.entrySet()
				.stream().filter(e->e.getValue()==1)
				.map(e->e.getKey()).collect(Collectors.toList());
		
		System.out.println("Unique number from list");
		for(Integer num:output) {
			
			System.out.println(num);
		}
		
		//fetch duplicate number from List
		
		Set<Integer> duplicateNum=new LinkedHashSet<>();
		
		Set<Integer> dupNumList=numberList.stream().filter(num->!duplicateNum.add(num))
		.collect(Collectors.toSet());
		
		System.out.println("Duplicate number from list");
		for(Integer num:dupNumList) {
			System.out.println(num);
		}
		
		
				
	}

}
