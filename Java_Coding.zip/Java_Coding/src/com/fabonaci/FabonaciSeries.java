package com.fabonaci;

public class FabonaciSeries {
	
	public static int fabonaci(int num) {
		if(num<=1) {
			return num;
		}
		return fabonaci(num-1) + fabonaci(num-2);
	}
	
	public static void main(String[] args) {
		
		int num=10;
	
		System.out.print("fabonaci series are: ");
		
		for(int i=0;i<num;i++) {
			System.out.print(fabonaci(i)+" ");
		}

	}

}
