package com.sortcountry;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CountryList {

	public static void main(String[] args) {
		
		//Fetch the country name which contain A and I character in descending order.
		
		List<String> countryList = Arrays.asList("INDIA","USA","AUSTRALIA","UK","CHINA","UROPE");
		
		
	List<String> output	=countryList.stream().
		filter(e->e.contains("A") && e.contains("I"))
		.sorted((e1,e2)->e2.compareTo(e1))
		.collect(Collectors.toList());
		
		System.out.println(output);
	}

}
