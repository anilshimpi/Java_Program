package com.countrepeatedword;

import java.util.LinkedHashMap;
import java.util.Map;

public class CountRepeatedWord {

	public static void main(String[] args) {
		
		String para="this is paragraph and this is sentence";
		String[] splitword=para.split(" ");
		
		LinkedHashMap<String,Integer> output=new LinkedHashMap<>();
		
		for(String count:splitword) {
			
			if(output.containsKey(count)) {
			  output.put(count, output.get(count)+1);	
			}
			else {
				output.put(count, 1);
			}
		}
		
		System.out.println(output);
		
		for(Map.Entry<String, Integer> entry:output.entrySet()) {
			System.out.println(entry.getKey()+": "+entry.getValue());
		}
	}

}
