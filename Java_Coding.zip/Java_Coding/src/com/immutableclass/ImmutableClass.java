package com.immutableclass;

import java.util.Date;

public final class ImmutableClass {

	private String name;
	private int date;
	
	public ImmutableClass(String name,int date){
		this.name=name;
		this.date=date;
	}
	
	public String getName() {
		return name;
	}
	
	public int getDate() {
		return date;
	}
	public static void main(String[] args) {
		
		ImmutableClass a=new ImmutableClass("Anil", 1990);
		System.out.println("Name: "+a.getName());
		System.out.println("Date: "+a.getDate());
		
	}

}
