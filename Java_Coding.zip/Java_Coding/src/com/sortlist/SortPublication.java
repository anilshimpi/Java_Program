package com.sortlist;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortPublication {

	public static void main(String[] args) {
		
		List<Publication> publicationList=Arrays.asList(
			new Publication("Anil", "Shimpi", "Java"),
			new Publication("Anand", "Sagar", "Mahabharat"),
			new Publication("Anil", "Sharma", "Python"),
			new Publication("Mukesh", "Khanna", "Shaktiman")
				);
		
		//sort first name and last name in natural sorting
		
		Comparator<Publication> sortFnameAndLname=Comparator.comparing(Publication::getlName)
				.thenComparing(Publication::getlName);
		
		//then sort bookname in descending order
		
		Comparator<Publication> sortBookName=Comparator
				.comparing(Publication::getBookName,Comparator.reverseOrder());
		
		List<Publication> finalList=publicationList.stream()
				.sorted(sortFnameAndLname.thenComparing(sortBookName)).collect(Collectors.toList());
		
		for(Publication list:finalList) {
			
			System.out.println("fName: "+list.getfName()+" LName: "+list.getlName()+" BookName: "+list.getBookName());
		}

	}

}
