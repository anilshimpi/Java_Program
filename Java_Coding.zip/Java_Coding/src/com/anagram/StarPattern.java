package com.anagram;

public class StarPattern {

	public static void main(String[] args) {

		/*
		*
		***
		*****
		********/
		
		for(int i=1;i<=10;i++) {
			for(int j=i;j>=10;j++) {
				if(j%i!=0)
					System.out.print("*");
				
			}
			System.out.println();
		}
		

	}

}
