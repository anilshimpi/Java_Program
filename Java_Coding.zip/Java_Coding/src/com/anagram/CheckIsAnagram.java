package com.anagram;

import java.util.Arrays;

public class CheckIsAnagram {
	
	public static void isAnagram(String s1,String s2) {
		
		//remove whitespace from string
		String str1=s1.replaceAll("\\s","");
		String str2=s2.replaceAll("\\s", "");
		
		boolean status=true;
		
		if(str1.length()!=str2.length()) {
			
			status=false;
		}
		else {
			char[] arrayS1=str1.toLowerCase().toCharArray();
			char[] arrayS2=str2.toLowerCase().toCharArray();
			
			Arrays.sort(arrayS1);
			Arrays.sort(arrayS2);
			status=Arrays.equals(arrayS1, arrayS2);
		}
		
		if(status) {
			
			System.out.println(str1+" And "+str2+" are Anagram");
		}
		else {
			System.out.println(str1+" And "+str2+" are not Anagram");
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		isAnagram("Keep", "Paek");
		isAnagram("Mother In Law", "Hitler Woman");
		isAnagram("Creat","Reacts");
	}

}
