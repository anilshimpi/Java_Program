package com.anagram;

public class RemovePattern {
	
public static void main(String[] args) {
		
		String str="abc#ab#";
		String[] splitStr=str.split("#");
		
		
		for(int i=0;i<splitStr.length;i++) {
			
			
			for(int j=0; j<splitStr[i].length()-1;j++) {
				
				System.out.print(splitStr[i].charAt(j));
			}
			
		}

	}

}
