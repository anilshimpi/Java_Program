package com.designpattern.builderdesignpattern;

public class User {
	
	//immutable class
	private final String name;
	private final String email;
	private final String id;
	
	private User(UserBuilder builder) {
		//initialization
		this.name=builder.name;
		this.email=builder.email;
		this.id=builder.id;
		
		
	}
	@Override
	public String toString() {
		return "User [name=" + name + ", email=" + email + ", id=" + id + "]";
	}
	
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public String getId() {
		return id;
	}
	
	//inner class to create object
	public static class UserBuilder{
		
		private  String name;
		private  String email;
		private  String id;
		
		public UserBuilder() {
			
			
		}
		
		public static UserBuilder builder() {
			return new UserBuilder();
		}
		
		public UserBuilder setName(String name) {
			this.name = name;
			return this;
		}
		public UserBuilder setEmail(String email) {
			this.email = email;
			return this;
		}
		public UserBuilder setId(String id) {
			this.id = id;
			return this;
		}
		
		
		public User build() {
		User user=	new User(this);
		return user;
		}
	}

}
