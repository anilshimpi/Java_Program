package com.designpattern.builderdesignpattern;

public class Main {

	public static void main(String[] args) {
		
		User user1=new User.UserBuilder().setId("User1")
		.setName("Anil").setEmail("anil@gmail.com").build();
		
		System.out.println(user1);
		
		User user2=User.UserBuilder.builder().setId("User2")
		.setName("Priti").build();
		System.out.println(user2);
		 
	}

}
