package com.designpattern.singleton;

public enum SingletonEnum {
	
	INSTANCE;
	
	void doSomething() {
		// TODO Auto-generated method stub
		System.out.println("do something...");
	}	

}
