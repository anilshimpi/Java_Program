package com.designpattern.singleton;

import java.io.IOException;

public class SynchronizeSingleton {
	
	private static SynchronizeSingleton synchronizeSingleton;
	
	private SynchronizeSingleton() {
		
	}
	
	public static SynchronizeSingleton getSynchronizeSingleton() throws IOException,NoSuchMethodException {
		
		if(synchronizeSingleton==null) {
		
			synchronized (SynchronizeSingleton.class) {
				if(synchronizeSingleton==null) {
					synchronizeSingleton=new SynchronizeSingleton();
				}
			}
		}
		return synchronizeSingleton;
	}
}
