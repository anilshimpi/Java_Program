package com.designpattern.singleton;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class SingletonExample {

	public static void main(String[] args) throws Exception,CloneNotSupportedException {

		// way to create singleton using lazy
		
		  LazySingleton lazySingleton=LazySingleton.getLazySingleton(); LazySingleton
		  lazySingleton1=LazySingleton.getLazySingleton();
		  
		  System.out.println(lazySingleton.hashCode());
		  System.out.println(lazySingleton1.hashCode());
		  
		 
		// way to create singleton using eager

		EagerSingleton eagerSingleton1 = EagerSingleton.getEagerSingleton();
		EagerSingleton eagerSingleton2 = EagerSingleton.getEagerSingleton();

		System.out.println(eagerSingleton1.hashCode());
		System.out.println(eagerSingleton2.hashCode());

		// way to create multiple thread based singleton object

		SynchronizeSingleton synchronizeSingleton1 = SynchronizeSingleton.getSynchronizeSingleton();
		SynchronizeSingleton synchronizeSingleton2 = SynchronizeSingleton.getSynchronizeSingleton();
		System.out.println(synchronizeSingleton1.hashCode());
		System.out.println(synchronizeSingleton2.hashCode());

		/*
		 * 1 .Replection API to break Singleton pattern 
		 * 
		 * Solution: 1-> if object is there
		 * ==> throw exception from inside constructor 
		 * 2->use ENUM
		 * 
		 * 2 Using Serialization and Deserialization we can break singleton pattern
		 * Solution: 1 - implement readResolve() method
		 * 
		 * 
		 * 3 break singleton using clonning
		 * 
		 * solution: 
		 * 1-> return same object instance in clone override method
		 * 
		 */

		System.out.println("--Break Singleton pattern using reflection");
		BreakSingletonUsingReplecationApi instaApi1 = BreakSingletonUsingReplecationApi
				.getBreakSingletonUsingReplecationApi();
		System.out.println(instaApi1.hashCode());
/*
		// break singleton using reflection

		Constructor<BreakSingletonUsingReplecationApi> constructor = BreakSingletonUsingReplecationApi.class
				.getDeclaredConstructor();
		constructor.setAccessible(true);
		BreakSingletonUsingReplecationApi instaApi2 = constructor.newInstance();
		System.out.println(instaApi2.hashCode());

		// using enum

		System.out.println("Solution to avoid break singleton using enum");
		SingletonEnum s1 = SingletonEnum.INSTANCE;
		s1.doSomething();
		System.out.println(s1.hashCode());

		Constructor<SingletonEnum> s2 = SingletonEnum.class.getDeclaredConstructor();
		s2.setAccessible(true);
		SingletonEnum s3 = s2.newInstance();
		System.out.println(s3.hashCode());

		// break Singleton serialization and deserialization

		LazySingleton serialize = LazySingleton.getLazySingleton();
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Object.obj"));
		oos.writeObject(serialize);
		System.out.println(serialize.hashCode());
		System.out.println("Serialization done...");

		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Object.obj"));
		LazySingleton deserialize = (LazySingleton) ois.readObject();
		System.out.println(deserialize.hashCode());
		*/
		
		//break singleton using clonning
		System.out.println("Break singleton using clonning");
		BreakSingletonUsingReplecationApi cloneObj= (BreakSingletonUsingReplecationApi) instaApi1.clone();
		System.out.println(instaApi1.hashCode());
		System.out.println(cloneObj.hashCode());

	}

}
