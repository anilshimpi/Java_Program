package com.designpattern.singleton;

public class EagerSingleton {
	
	//way to create singleton object instance using eager way
	private static EagerSingleton eagerSingleton=new EagerSingleton();
	
	//private constructor
	private EagerSingleton() {
		
		
	}
	
	public static EagerSingleton getEagerSingleton() {
		
		if(eagerSingleton==null) {
			return eagerSingleton;
		}
		return eagerSingleton;
	}
}
