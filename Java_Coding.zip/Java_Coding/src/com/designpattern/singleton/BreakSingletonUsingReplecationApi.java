package com.designpattern.singleton;

import java.io.Serializable;

public class BreakSingletonUsingReplecationApi implements Serializable ,Cloneable {
	
	private static BreakSingletonUsingReplecationApi instaApi;
	
	//Solution to avoid break singleton pattern with proper exception
	private BreakSingletonUsingReplecationApi() {
		
	}
	
	public static BreakSingletonUsingReplecationApi getBreakSingletonUsingReplecationApi() {
		if(instaApi==null) {
			instaApi=new BreakSingletonUsingReplecationApi();
		}
		return instaApi;
	}
	
	//solution to for when break singleton using serialization and deserialization
	
	public Object readResolve() {
		return instaApi;
	}

	//override clone method
	@Override
	public Object clone() throws CloneNotSupportedException{
		
		//Break singletone using clone method -->return super.clone()
		//return super.clone();
		
		//Solution: return same object instance to avoid break singleton to clone method
		return instaApi;
	}
}
