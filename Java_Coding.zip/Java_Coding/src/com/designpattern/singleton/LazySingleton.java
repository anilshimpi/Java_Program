package com.designpattern.singleton;

public class LazySingleton {
	
	private static LazySingleton lazySingleton;
	
	//private constructor
	private LazySingleton() {
		
	}
	
	//way to create object by lazy way
	public static LazySingleton getLazySingleton() {
		
		if(lazySingleton==null) {
			lazySingleton=new LazySingleton();	
		}
		return lazySingleton;
	}
}
