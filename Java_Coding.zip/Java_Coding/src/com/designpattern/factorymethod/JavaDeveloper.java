package com.designpattern.factorymethod;

public class JavaDeveloper implements Employee {

	@Override
	public int salary() {
	
		System.out.println("Getting salary for Java Developer");
		return 80000;
	}

}
