package com.designpattern.factorymethod;

public class FullStackDeveloper implements Employee {

	@Override
	public int salary() {
		System.out.println("Getting salary for Java FullStack Developer");
		return 120000;
	}

}
