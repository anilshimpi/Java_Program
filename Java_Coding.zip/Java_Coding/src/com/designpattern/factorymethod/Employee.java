package com.designpattern.factorymethod;

public interface Employee {
	
	public int salary();

}
