package com.designpattern.factorymethod;

public class EmployeeClient {

	public static void main(String[] args) {

		Employee emp1=EmployeeFactory.getEmployee("Java Developer");
		System.out.println("Salary: "+emp1.salary());
		
		Employee emp2=EmployeeFactory.getEmployee("FullStack Developer");
		System.out.println("Salary: "+emp2.salary());

	}

}
