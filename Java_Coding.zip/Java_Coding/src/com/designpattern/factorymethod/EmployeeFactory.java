package com.designpattern.factorymethod;

public class EmployeeFactory {
	
	public static Employee getEmployee(String empType) {
		
		if(empType.trim().equalsIgnoreCase("JAVA DEVELOPER")) {
			return new JavaDeveloper();
		}
		else if(empType.trim().equalsIgnoreCase("FULLSTACK DEVELOPER")) {
			return new FullStackDeveloper();
		}
		else {
			return null;
		}
			
	}

}
