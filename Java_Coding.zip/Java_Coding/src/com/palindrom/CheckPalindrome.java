package com.palindrom;

public class CheckPalindrome {
	
	public static boolean isPalindrom(String input) {
		input=input.replaceAll("\\s", "").toLowerCase();
		
		for(int i=0;i<input.length()/2;i++) {
			if(input.charAt(i)!=input.charAt(input.length()-1-i)) {
				
				return false;
			}
			
		}
		
		return true;
	}

	public static boolean isPalindrom(int number) {
		return isPalindrom(String.valueOf(number));
	}
	public static void main(String[] args) {

		String word="Madam";//modam
		int num=12321; //12321
		
		if(isPalindrom(word)) {
			System.out.println(word+" is palindrom");
		}
		else {
			System.out.println(word+" is not palindrom");
		}
		
		if(isPalindrom(num)) {
			System.out.println(num+" is palindrom");
		}
		else {
			System.out.println(num+" is not palindrom");
		}

	}

}
