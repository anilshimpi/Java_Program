package com.palindrom;

public class CheckPalindrom {
	
	public static boolean isPalindrom(int input) {
		
		int originalNum=input;
		int reverseNum=0;
		
		for(int temp=input;temp!=0;temp/=10) {
			int digit=temp%10;
			reverseNum=reverseNum*10+digit;
			
		}
		return reverseNum==originalNum;
	}

	public static void main(String[] args) {
		
		int num=121;
		
		if(isPalindrom(num)) {
			System.out.println("Given number "+num+ " is palindrom");
		}
		else {
			System.out.println("Given number "+num+ " is not palindrom");
		}
	}

}
