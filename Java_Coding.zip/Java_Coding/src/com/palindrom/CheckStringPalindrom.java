package com.palindrom;

public class CheckStringPalindrom {

	public static boolean isPalindrom(String input) {
		
		input=input.replaceAll("\\s","").toLowerCase();
		
		for(int i=0;i<=input.length()/2;i++) {
			
			if(input.charAt(i)!=input.charAt(input.length()-1-i)) 
				return false;
				
		}
		return true;
	}
	private static boolean isPalindrom(int input) {
		return isPalindrom(String.valueOf(input));
	}
	public static void main(String[] args) {
		
		String input="Madam";
		int num=121;
		
		if(isPalindrom(input)) {
			System.out.println("Given string "+input+" is palindrom");
		}
		else {
			System.out.println("Given string "+input+" is not palindrom");
		}
		
		if(isPalindrom(num)) {
			System.out.println("Given number "+num+" is palindrom");
		}
		else {
			System.out.println("Given number "+num+" is not palindrom");
		}
	}

}
