package com.palindrom;

public class CheckPanindromNum {

	public static boolean isPalindrom(int num) {
		int originalNum=num;
		int reverseNun=0;
		
		for(int temp=num;temp!=0;temp=temp/10) {
			int digit=temp%10;
			reverseNun=reverseNun*10 +digit;
			
		}
		//System.out.println(reverseNun);
		return originalNum==reverseNun;
	}
	public static void main(String[] args) {
		
		int num=12431; //12431
		
		if(isPalindrom(num))
			System.out.println(num+ " is Palindrom");
		else
			System.out.println(num+" is not palindrom");

	}

}
