package com.sortbyvalue;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class SortValueUsingMap {

	public static void main(String[] args) {
		
		LinkedHashMap<String,String> capital= new LinkedHashMap<>();
		
		capital.put("Mumbai", "MH");
		capital.put("Pune", "ABC");
		capital.put("Indore", "PQR");
		capital.put("Gandhi Nagar", "Gujarat");
		
		LinkedHashMap<String, String> output=sortMapByValue(capital);
		
		for(Map.Entry<String,String> entry:output.entrySet()) {
			
			System.out.println("Key: "+entry.getKey()+" Value: "+entry.getValue());
		}

	}

	public static LinkedHashMap sortMapByValue(LinkedHashMap<String, String> map) {
		
		List<Map.Entry<String, String>> capitallist= new LinkedList<>(map.entrySet());
		
		Collections.sort(capitallist,(o1,o2) -> o1.getValue().compareTo(o2.getValue()));
		
		LinkedHashMap<String, String> output=new LinkedHashMap<>();
		
		for(Map.Entry<String, String> entry:capitallist) {
			
			output.put(entry.getKey(),entry.getValue());
			
		}
		
		
		return output;
	}
}
