package com.findnonrepeatedfirstchar;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class FindFirstNonReatedChar {
	
	public static char getFirstNonRepeatedChar(String str) {
		
		LinkedHashMap<Character,Integer> charCount= new LinkedHashMap<>(str.length());
		
		for(char ch:str.toCharArray()) {
			
			charCount.put(ch, charCount.containsKey(ch) ? charCount.get(ch)+1:1);
		}
		for(Entry<Character,Integer> entry:charCount.entrySet()) {
			
			if(entry.getValue()==1)
			return entry.getKey();
		}
		throw new RuntimeException("Didnt find any non repeated character");
	}

	public static void main(String[] args) {
		
		String str="aabbccdef";
		char ch=getFirstNonRepeatedChar(str);
		System.out.println("First Repated character is "+ch);
		
		

	}

}
