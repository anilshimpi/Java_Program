package com.singleton;

public class SingletonClassExample {
	
	private static SingletonClassExample instance=null;
	
	public String str;
	
	private SingletonClassExample() {
		str="This is singleton class example";
	}
	
	public static SingletonClassExample getInstance() {
		
		if(instance==null) {
			instance=new SingletonClassExample();
			
		}
		return instance;
	}

	public static void main(String[] args) {
		
		SingletonClassExample a=SingletonClassExample.getInstance();
		SingletonClassExample b=SingletonClassExample.getInstance();
		
		System.out.println("a-"+a.str);
		System.out.println("b-"+b.str);
	}

}
