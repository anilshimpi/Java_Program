package com.reversestring;

public class ReverseStringDemo {

	public static void main(String[] args) {

		String str="Anil";
		String s=str.toLowerCase();
		char ch;
		String rev="";
		
		
		for(int i=0;i<s.length();i++) {
			
			ch=s.charAt(i);
			rev=ch+rev;	
			
		}
		String s1=rev.substring(0,1).toUpperCase()+rev.substring(1).toString();
		System.out.println(s1);
	}

}
