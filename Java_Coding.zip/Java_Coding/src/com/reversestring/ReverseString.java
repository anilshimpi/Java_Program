package com.reversestring;

public class ReverseString {

	public static void main(String[] args) {
		
		String str="Anil";
		char ch;
		String rev="";
		
		for(int i=0;i<str.length();i++) {
			
			ch=str.charAt(i);
			rev=ch+rev;
		}
		System.out.println("Reverse string is: "+rev);
	}

}
