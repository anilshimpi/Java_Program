package com.flatmap;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FlatMapDemo {

	public static void main(String[] args) {
		
		List<Integer> numInt= new ArrayList<>();
		numInt.add(1);
		numInt.add(2);
		
		List<Integer> numInt1= new ArrayList();
		numInt1.add(3);
		numInt1.add(4);
		
		List<List<Integer>> finalList= new ArrayList();
		finalList.add(numInt);
		finalList.add(numInt1);
		
		List<Integer> out=finalList.stream().flatMap(e->e.stream()).collect(Collectors.toList());
		
		System.out.println(out);
	}

}
