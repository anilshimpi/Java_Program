package com.checkprime;

public class PrintNPrimeNumber {
	
	public static void main(String[] args) {
		
		int number =10,count;
		
		System.out.println("Print prime number from 1 to "+number+" :");
		
		for(int input=1;input<=number;input++) {
			
			count=0;
			
			for(int j=2;j<=input/2;j++) {
				if(input%j==0) {
					count++;
					//break;
				}
				
			}
			
			if(count==0 && input!=1) {
				System.out.print(input+" ");
			}
		}
	
	}

}
