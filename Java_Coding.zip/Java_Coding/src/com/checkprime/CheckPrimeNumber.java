package com.checkprime;

public class CheckPrimeNumber {

	public static boolean isPrime(int num) {
		
		for(int i=2;i<=num/2;i++) {
		
			if(num%i==0) 
				return false;
			
		}
		return true;	
		}
	
	public static void main(String[] args) {
		
		
		int number=11;
		
		if(isPrime(number)) {
			System.out.println(number+ " is prime number");
		}
		else {
			System.out.println(number+ " is not prime number");
		}
	}

}
