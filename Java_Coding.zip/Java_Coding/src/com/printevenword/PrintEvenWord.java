package com.printevenword;

public class PrintEvenWord {

	public static void main(String[] args) {
		// print even word from given string
		
		String str="Hell words we lol";
		
		for(String s: str.split(" ")) {
			if(s.length()%2==0)
				System.out.print(s+" ");
		}
	}

}
