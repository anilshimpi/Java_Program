package com.factorial;

public class FactorialNumber {
	
	public static long factorialNum(long n) {
		
		if(n==0||n==1) {
			return 1;
		}
		else {
			return n*factorialNum(n-1); //20
		}
	}

	public static void main(String[] args) {
		
		long num=5;
		
	//	long factorial=factorialNum(num);
		
		System.out.println("Factorial number for "+num+ " is:"+factorialNum(num));

	}

}
