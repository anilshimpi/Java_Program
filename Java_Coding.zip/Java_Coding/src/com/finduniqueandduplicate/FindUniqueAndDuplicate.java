package com.finduniqueandduplicate;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FindUniqueAndDuplicate {

	public static void main(String[] args) {
		
		List<Integer> numberList=Arrays.asList(1,2,2,3,4,5,6,7,6,3);
		
		//find unique number
		
Map<Integer,Long>	uniqueNum=	numberList.stream()
.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));

List<Integer> output=uniqueNum.entrySet().stream()
.filter(e->e.getValue()==1).map(e->e.getKey()).collect(Collectors.toList());

System.out.println("Unique number are: ");
output.forEach(System.out::println);

//fetch duplicate
	Set<Integer> duplicateNum=new HashSet<>();
	
	Set<Integer> num1=numberList.stream().filter(num->!duplicateNum.add(num)).collect(Collectors.toSet());
	
	System.out.println("Duplicate number are: ");
	num1.forEach(System.out::println);
	
	}

}
