package com.reverseword;

public class ReverseWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str="Welcome to java word";
		String[] split=str.split(" ");
		
		for(int i=split.length-1;i>=0;i--) {
			System.out.print(split[i]+" ");
		}

	}

}
