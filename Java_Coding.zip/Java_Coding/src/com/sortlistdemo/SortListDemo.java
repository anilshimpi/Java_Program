package com.sortlistdemo;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;



public class SortListDemo {

	public static void main(String[] args) {

		List<Publisher> publicationList=Arrays.asList(
				new Publisher("Anil", "Shimpi", "Java"),
				new Publisher("Anand", "Sagar", "Mahabharat"),
				new Publisher("Anil", "Sharma", "Python"),
				new Publisher("Mukesh", "Khanna", "Shaktiman")
					);
		
		//sort fname and last name in asscending
		
		Comparator<Publisher> fnameAndLName=Comparator.comparing(Publisher::getfName).thenComparing(Publisher::getlName);
		
		//sort book name by descending
		Comparator<Publisher> bookName=Comparator.comparing(Publisher::getBookName,Comparator.reverseOrder());
		
		List<Publisher> output=publicationList.stream()
				.sorted(bookName.thenComparing(fnameAndLName)).collect(Collectors.toList());
		
		output.forEach(e->{
			System.out.println(e.getfName()+" "+e.getlName()+" "+e.getBookName());
			
		});
	}

}
