package com.sortlistdemo;

public class Publisher {
	
	private String fName;
	private String lName;
	private String bookName;
	
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public Publisher(String fName, String lName, String bookName) {
		super();
		this.fName = fName;
		this.lName = lName;
		this.bookName = bookName;
	}
	
	
	

}
