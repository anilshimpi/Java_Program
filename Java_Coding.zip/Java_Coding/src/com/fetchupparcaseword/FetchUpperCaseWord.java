package com.fetchupparcaseword;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FetchUpperCaseWord {

	public static void main(String[] args) {
	
		List<String> list =Arrays.asList("ANIL","PRITI","ADVAIT","anil","Shimpi");
		
		ArrayList<String> uppercaseWord= new ArrayList<>();
		
		for(String result:list) {
			if(result.matches("[A-Z][^A-Z]+"))
			uppercaseWord.add(result);
		}
		System.out.println(uppercaseWord);
		

		//using stream
		
		List<String> upper=list.stream().filter(e->e.matches("[A-Z]+") || e.matches("[a-z]+")).collect(Collectors.toList());
		System.out.println(upper);
	}
	
}
