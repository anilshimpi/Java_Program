package com.countoccurance;
import java.util.LinkedHashMap;
import java.util.Map;

public class StringOccurance {

	public static void main(String[] args) {
		
		String para="aabbbccdda";
		String[] splitPara =para.split("");
		
		LinkedHashMap<String,Integer> result=new LinkedHashMap<>();
		
		for(String s:splitPara) {
			
			if("".equals(s))
				continue;
			
			Integer count=result.get(s);
			if(count!=null) {
				result.put(s, ++count);
			}
			else {
				result.put(s, 1);
			}
		}
		StringBuffer output=new StringBuffer("");
		
		for(Map.Entry<String, Integer> entry:result.entrySet()) {
			
			output.append(entry.getValue()).append(entry.getKey());
		}
		System.out.println(output);
	}

}
