package com.countwordinstring;

public class CountWordInString {

	public static void main(String[] args) {
		// Count the word present in string
		
		String str="Welcome the java word";
		
		int count=0;
		
		if(str.charAt(0)!=' ')
			count++;
		
		for(int i=0;i<str.length();i++) {
			
			if(str.charAt(i)==' '&& str.charAt(i+1)!=' ')
				count++;
			
			
		}
		System.out.println("Number of word present is String = "+count);
	}

}
