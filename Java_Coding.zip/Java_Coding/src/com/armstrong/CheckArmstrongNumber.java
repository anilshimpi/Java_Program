package com.armstrong;

public class CheckArmstrongNumber {
	
	public static int power(int x,int y) {
		if(y==0) {
			return 1;
		}
		if(y%2==0) {
			return power(x,y/2) * power(x,y/2);
		}
		return x*power(x,y/2)*power(x,y/2);
	}

	public static int order(int x) {
		
		int n=0;
		while(x!=0){
			n++;
			x=x/10;
		}
		return n;
	}
	
	public static boolean isArmstong(int num) {
		
		int n=order(num);
		int temp=num,sum=0;
		while(temp!=0) {
			int r=temp%10;
			sum=sum+power(r,n);
			temp=temp/10;
		}
		
		return sum==num;
	}
	public static void main(String[] args) {

		int num=153;
		
		if(isArmstong(num)) {
			System.out.println(num+ " is Armstrong number");
		}
		else {
			System.out.println(num+ " is not Armstrong number");
		}
	}

	

}
