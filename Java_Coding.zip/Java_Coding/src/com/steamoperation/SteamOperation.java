package com.steamoperation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SteamOperation {

	public static void main(String[] args) {
		
		List<Employee> list =Arrays.asList(
				new Employee(11, "Anil", 80000),
				new Employee(12,"Priti",40000),
				new Employee(13,"Advait",20000),
				new Employee(14,"ABC",60000)
				);
		
		//fetch highest salary
		
		Employee highestSalary=list.stream()
				.sorted(Comparator.comparingDouble(Employee::getSalary).reversed())
		.findAny().get();
		System.out.println("Highest Salary: "+highestSalary.getSalary());
		
		
		//fetch second highest salary
		
		Employee secondHighestSal=list.stream().sorted(Comparator.comparingDouble(Employee::getSalary).reversed())
				.skip(1).findFirst().get();
		
		System.out.println("Second Highest Salary: "+secondHighestSal.getSalary());
		
		//Sort by salary
		
		List<Employee> sortBySalary=list.stream()
				.sorted(Comparator.comparingDouble(Employee::getSalary).reversed())
				.collect(Collectors.toList());
		
	
		
		System.out.println("Fetch employee details sort salary by descending order: ");
		
		for(Employee e:sortBySalary) {
			System.out.println("Id: "+e.getId()+" Name: "+e.getName()+" Salary: "+e.getSalary());
		}
		
		

	}

	

}
