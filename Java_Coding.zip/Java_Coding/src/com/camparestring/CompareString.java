package com.camparestring;

public class CompareString {
	
public static void main(String[] args) {
		
		String str1="abcd";
		String str2="abcd";
	
	if(isCompare(str1,str2))
		System.out.println("Both string are equals");
	else
		System.out.println("Both string are not equals");
	}
	
public static boolean isCompare(String str1,String str2) {
		
		
		if(str1.length()!=str2.length())
			return false;
	
		for(int i=0;i<str1.length();i++) {
			if(str1.charAt(i)!=str2.charAt(i))
				return false;
		}
	
		return true;	
	}
}
