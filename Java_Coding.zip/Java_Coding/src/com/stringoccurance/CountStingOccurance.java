package com.stringoccurance;

import java.util.LinkedHashMap;
import java.util.Map;

public class CountStingOccurance {
	

	public static void main(String[] args) {
	
		String para="aaaabbccddab";
		
		String[] str=para.split("");
		
		Map<String,Integer> countOccurance= new LinkedHashMap<>();
		
		for(String s:str) {
			
			if("".equals(str))
				continue;
			
			Integer count=countOccurance.get(s);
			if(count!=null) {
				countOccurance.put(s, ++count);
				
			}
			else {
				countOccurance.put(s, 1);
			}
		}
			
			StringBuffer output=new StringBuffer("");
			
			for(Map.Entry<String, Integer> entry:countOccurance.entrySet()) {
				
				output.append(entry.getValue()).append(entry.getKey());
			//	System.out.println(entry.getKey()+": "+entry.getValue());
				
			}
			
			System.out.println(output);
		}					

}
