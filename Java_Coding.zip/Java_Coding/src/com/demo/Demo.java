package com.demo;

public class Demo {
	
	public static void main(String[] args) {
		
		System.out.println(10+20+"Hello");
		System.out.println("Hello"+10+20);
		//String 
		String s="Hello";
		s="Hello words";
		String s1=s.concat(" Word");
		System.out.println(s);
		System.out.println(s1);
	}

}
