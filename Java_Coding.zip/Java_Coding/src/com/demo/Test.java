package com.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;

public class Test {

	public static void main(String[] args) {
		
		// Creating an object of List interface with
        // reference to ArrayList
        List<Integer> al = new ArrayList<>();
  
        // Adding elements to ArrayList class
        // using add() method
        al.add(10);
        al.add(20);
        al.add(30);
        al.add(1);
        al.add(2);
  
        // Printing the current ArrayList
        System.out.println(al);
		

		//remove the element 5
		al.remove(Integer.valueOf(30));
		System.out.println("After remove element");
		for(Integer output:al) {
			System.out.println(output);
		}
		
	}

}
