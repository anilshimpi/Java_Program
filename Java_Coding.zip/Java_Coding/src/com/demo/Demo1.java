package com.demo;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Demo1 {

	public static void main(String[] args) {
		
		//employee list who has salary greater than 10000
		
		List<Employee> empList= Arrays.asList(
				new Employee("Anil",20000),
				new Employee("ABC",5000),
				new Employee("XYZ",10000),
				new Employee("PQR",25000)
				
				);
			
	List<Employee> list=	empList.stream().filter(e->e.getSalary()>10000).collect(Collectors.toList());
	
		for(Employee emp:list) {
			System.out.println(emp.getName()+ ":"+emp.getSalary());
		}
	}

}
