package com.palindromicpermutation;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PalindromicPermutation {
	
	public static Set<String> genetatePalindromicPermutation(String str) {
		
		Set<String> result= new HashSet<>();
		generatePermutation(str.toCharArray(),0,result);
		return result;
		
	}

	private static void generatePermutation(char[] chars,int index,Set<String> result) {
		
		if(index==chars.length-1) {
			result.add(String.valueOf(chars));
		}
		else {
			for(int i=index;i<chars.length;i++) {
				swap(chars,index,i);
				generatePermutation(chars, index+1, result);
				swap(chars,index, i);
			}
		}
	}
	
	private static void swap(char[] chars,int i, int j) {
		char temp=chars[i];
		chars[i]=chars[j];
		chars[j]=temp;
	}
	
	public static void main(String[] args) {
		
		String str="add";
		
		Set<String> palindromicPermutation=genetatePalindromicPermutation(str);
		
		System.out.println("Palindromic Permutations for "+str+":");
		
		for(String permutation:palindromicPermutation) {
			
			System.out.print(permutation+" ");
		}
		
	}

}
