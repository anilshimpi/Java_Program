package com.palindromicpermutation;

import java.util.HashSet;
import java.util.Set;

public class Demo {
	
public static Set<String> generatePalindromicPermutation(String str){
        
        Set<String> result= new HashSet<>();
        palindromicPermutation(str.toCharArray(),0,result);
        return result;
        
    }
    
    public static void palindromicPermutation(char[] chars,int index,Set<String> result){
        if(index==chars.length-1){
        result.add(String.valueOf(chars));
        }
        else{
            for(int i=index;i<chars.length;i++){
                swap(chars,index,i);
                palindromicPermutation(chars,index+1,result);
                 swap(chars,index,i);
            }
                
            }
            
        }
        private static void swap(char[] chars, int i,int j){
            char temp=chars[i];
            chars[i]=chars[j];
            chars[j]=temp;
            
        }

	public static void main(String[] args) {
		
		 String str="add";
		    Set<String> palindromicPermutation=  generatePalindromicPermutation(str);
		    
		    System.out.println("Given string"+str+" palindromic permutation are: ");
		    for(String output:palindromicPermutation){
		      System.out.println(output);  
		    }
	}

}
