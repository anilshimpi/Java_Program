package com.listdemo;

public class StringDemo {

	public static void main(String[] args) {
		
		String s = "Hello ";
		 s = s.concat("World");
		 System.out.println(s);

	}
	//output: - Hello Word
	
	//if String s = null; then output will be : - Exception in 
	//thread "main" java.lang.NullPointerException: Cannot invoke "String.concat(String)" because "s" is null
//	at com.listdemo.StringDemo.main(StringDemo.java:8)
}
