package com.listdemo;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ListDemo {

	public void Test() {
		
	//	Example of method overiding exception
			
		System.out.println("Parent test Method");
	}

}
