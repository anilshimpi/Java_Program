package com.listdemo;

import java.io.IOException;

public class ChildDemo extends ListDemo {
	
	/* If parent class didnt throws any exception the in override method of child class
	if you want throw  exception then you can throws only unchecked exception not checked.*/
	
	@Override
	public void Test() throws RuntimeException {
	
		System.out.println("This is child test method");
		
	}

	public static void main(String[] args) {
		
		 
		
		
	}

}
