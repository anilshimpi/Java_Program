package com.yash.yotaapi.exception;

/*This class use to handle custome BatchIdException*/
public class BatchIdException extends RuntimeException {

	public BatchIdException(String msg) {
		super(msg);
	}
	
}
