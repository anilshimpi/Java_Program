package com.yash.yotaapi.exception;

public class DateInValidException extends RuntimeException {
	
	public DateInValidException(String msg) {
		
		super(msg);
	}

}
