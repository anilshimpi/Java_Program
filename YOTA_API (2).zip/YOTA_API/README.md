# YOTA_API

This repository will be used to manage the YOTA Back end api using spring boot.
We are using Java version 1.8 with Spring boot 2.7.8 in this project so Please make sure that you are on also same pace with us.

